# performance.R - DESC
# /performance.R

# Copyright Iago MOSQUEIRA (WMR), 2019
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
#
# Distributed under the terms of the EUPL-1.2


library(mse)

# LOAD example indicators

data(indicators)

# SUBSET some indicators

inds <- indicators[c(2, 3, 4, 7, 8, 9)]

inds[[1]]

# LOAD results

load('../../../data/datarich.RData')
load('../../../data/datalimited.RData')

# SELECT relevant refpts

refs <- FLPar(
	SBMSY = res.dr@refpts["msy", "ssb"], 
	Ftarget = res.dr@refpts["f0.1","harvest"], 
	FMSY = res.dr@refpts["msy", "harvest"], 
	SBlim = res.dr@refpts["spr.30","ssb"])

metrics <- list(SB = ssb, F = fbar, C = catch)

# COMPUTE performance along whole TS

perf.dr <- performance(stock(res.dr), refpts = refs, indicators=inds,
  metrics = metrics, years=list(2016:2041))

# INSPECT

perf.dr

# RECOMPUTE for short and long term

perf.drsl <- performance(stock(res.dr), refpts = refs, indicators=inds,
  metrics = metrics, years=list(2016:2041, 2016:2021))

perf.drsl

# SOME plotting

ggplot(perf.drsl, aes(x=name, y=data)) + geom_boxplot() +
  facet_grid(indicator~year, scales="free") +
  xlab("") + ylab("") + theme(axis.text.x = element_text(angle = 90))


# --- MANUALLY computing indicators

# DEBUG F / FMSY
ffmsy <- fbar(stock(res.dr)) / refpts(res.dr)["msy","harvest"]

plot(iterSums(ffmsy > 1) / 25)

# CATCH stability

cest <- (catch(stock(res.dr)[,-26]) - catch(stock(res.dr)[,-1])) / 
  catch(stock(res.dr)[,-26])

plot(cest) + geom_hline(yintercept=0)

# --- TODO DEFINE and COMPUTE your own indicator

inds[[1]]


# --- COMPUTING performance over time

# SELECT indicators

indts <- indicators[c("red", "green")]

# SPECIFY years as vector

perf.drts <- performance(stock(res.dr), refpts = refs, indicators=indts,
  metrics = metrics, years=2016:2041)

ggplot(perf.drts, aes(x=ISOdate(year,1,1), y=data, group=name, colour=indicator)) +
  geom_line() + xlab("") + ylab("P(kobe)")

# --- COMPUTE performance by mp

stocks <- FLStocks(DR=stock(res.dr), DL=stock(res.dl))

perf <- performance(stocks, refpts = refs, indicators=inds,
  metrics = metrics, years=list(2016:2041))

save(perf, inds, file="perf.RData")
save(perf, inds, file="../../../data/perf.RData")



