 # r=fmsy/(1/(1+p))
 # k=bmsy/((1/(1+params['p']))^(1/params['p']))
 
 