t0<-function(linf,k)
   -exp(-0.3922-0.2752*log(linf)-1.038*log(k))
