# wur.R - DESC
# wmrkdown/R/wur.R

# Copyright Iago MOSQUEIRA (WMR), 2019
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
#
# Distributed under the terms of the EUPL-1.2

# wur {{{
wur <- function(toc = FALSE,
  slide_level = 1,
  incremental = FALSE,
  fig_width = 5,
  fig_height = 4,
  fig_crop = TRUE,
  fig_caption = FALSE,
  dev = 'pdf',
  df_print = "default",
  fonttheme = "default",
  highlight = "tango",
  keep_tex = FALSE,
  latex_engine = "pdflatex",
  citation_package = c("none", "natbib", "biblatex"),
  includes = NULL,
  md_extensions = NULL,
  pandoc_args = NULL) {


    # COPY beamertheme
    file.copy(system.file("rmarkdown", "templates", "wur", "skeleton",
      "beamerthemewurnew.sty", package="wur"), ".",  recursive=TRUE)

    # COPY front.png, logo.png
    file.copy(system.file("rmarkdown", "templates", "wur", "skeleton",
      c("front.png", "logo.png", "default.png"), package="wur"), ".",  recursive=TRUE)

    template <- system.file("rmarkdown", "templates", "wur",
      "resources", "template.tex", package="wmrkdown")
    
    rmarkdown::beamer_presentation(template = template,
      toc = toc,
      slide_level = slide_level,
      incremental = incremental,
      fig_width = fig_width,
      fig_height = fig_height,
      fig_crop = fig_crop,
      fig_caption = fig_caption,
      dev = dev,
      df_print = df_print,
      theme = "wurnew",
      fonttheme = fonttheme,
      highlight = highlight,
      keep_tex = keep_tex,
      latex_engine = latex_engine,
      citation_package = citation_package,
      includes = includes,
      md_extensions = md_extensions,
      pandoc_args = pandoc_args)

} # }}}
