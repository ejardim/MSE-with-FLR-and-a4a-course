# wmr.R - DESC
# wmrkdown/demo/wmr.R

# Copyright Iago MOSQUEIRA (WMR), 2019
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
#
# Distributed under the terms of the EUPL-1.2

library(wmrkdown)
library(rmarkdown)

# CREATE an empty presentation from template

fn <- draft("myslides.Rmd", template="wur", package="wmrkdown", edit=FALSE)
setwd("myslides")  ## template creates a new subdir
render("myslides.Rmd")
