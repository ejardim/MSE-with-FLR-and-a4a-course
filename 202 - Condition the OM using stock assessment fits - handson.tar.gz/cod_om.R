#####################################################################
# COD MSE for Course
# 20191111
#####################################################################

#====================================================================
# libraries, code, input data and MSE setup
#====================================================================
rm(list = ls())
library(FLa4a)
library(mse)
library(FLAssess)
library(ggplotFL)
library(FLBRP)

#--------------------------------------------------------------------
# data and preprocessing
#--------------------------------------------------------------------
attach("../../../data/cod.RData")
aa.stk <- stk
idxs <- idxs
detach()

#--------------------------------------------------------------------
# MSE setup
#--------------------------------------------------------------------
it <- 75 # iterations
y0 <- range(aa.stk)["minyear"] # initial OM year
dy <- range(aa.stk)["maxyear"] # final OM year
fy <- dy + 21 # final year
iy <- dy  # initial year of projection (also intermediate)
ny <- fy - iy + 1 # number of years to project from intial year
nsqy <- 3 # number of years to compute status quo metrics
vy <- ac(iy:fy) # vector of years to be projected

#====================================================================
# OM conditioning - Base case
#====================================================================

#--------------------------------------------------------------------
# Assessment
#--------------------------------------------------------------------
brn <- 50 # If you dont use mcmc put burn equal zero to avoid mismatch dimension in the matrix later on
mcsave <- 100
mcmc <- mcsave*it
# mcmc setup object
scamcmc <- SCAMCMC(mcmc = mcmc, mcsave = mcsave, mcprobe = 0.3)

# submodels
qmod <- list(~s(age, k=3), ~s(age, k=3))
fmod <- ~te(age, year, k = c(3, 15)) + s(age, k = 5)
srmod <- ~geomean(CV=0.3)

# run
fit <- sca(aa.stk, idxs, fmodel=fmod, qmodel=qmod, srmodel=srmod, fit="MCMC", mcmc = scamcmc)
fit <- burnin(fit, brn)
stk <- aa.stk + fit
plot(stk)
wireframe(data ~ age + year, data = as.data.frame(harvest(stk)), drape = TRUE, screen = list(x = -90, y=-45))

# status quo F
fsq <- mean(fbar(stk)[,ac(dy:(dy-nsqy+1))])

#--------------------------------------------------------------------
# S/R
# use medians to avoid fitting to each iter
#--------------------------------------------------------------------

stk0 <- qapply(stk, iterMedians)
gsr  <- as.FLSR(stk0, model = "bevholt")
gsr <- fmle(gsr)
plot(gsr)

#--------------------------------------------------------------------
# Set residuals for the projections period using residuals sd for
# rlnorm
#--------------------------------------------------------------------
res_gsr <- window(rec(stk), end=fy)
res_gsr <- rlnorm(res_gsr, 0, sd(residuals(gsr)))
residuals(gsr) <- res_gsr
plot(residuals(gsr))

#--------------------------------------------------------------------
# reference points
#--------------------------------------------------------------------
brp_gsr <- brp(FLBRP(stk0, gsr))
refpts(brp_gsr)

#--------------------------------------------------------------------
# extend object for fwd, set up future assumptions - means of nsqy years
#--------------------------------------------------------------------
stk <- stf(stk, fy-dy, nsqy, nsqy)
plot(stk)

#--------------------------------------------------------------------
# build OM object
#--------------------------------------------------------------------
# set projection method for OM
proj <- mseCtrl(method=fwd.om, args=list(maxF=3))
# build object
stk.om_base <- FLom(stock=stk, sr=gsr, refpts=refpts(brp_gsr), projection=proj)

#####################################################################

#====================================================================
# OM conditioning - Alternative fmodel
#====================================================================

#--------------------------------------------------------------------
# Assessment
#--------------------------------------------------------------------
brn <- 50 # If you dont use mcmc put burn equal zero to avoid mismatch dimension in the matrix later on
mcsave <- 100
mcmc <- mcsave*it
# mcmc setup object
scamcmc <- SCAMCMC(mcmc = mcmc, mcsave = mcsave, mcprobe = 0.3)

# submodels
qmod <- list(~s(age, k=3), ~s(age, k=3))
##### Alt setting ###############
fmod1 <- ~factor(age) + factor(year)
#################################
srmod <- ~geomean(CV=0.3)

# run
fit1 <- sca(aa.stk, idxs, fmodel=fmod1, qmodel=qmod, srmodel=srmod, fit="MCMC", mcmc = scamcmc)
fit1 <- burnin(fit1, brn)
stk1 <- aa.stk + fit1
plot(stk1)
wireframe(data ~ age + year, data = as.data.frame(harvest(stk1)), drape = TRUE, screen = list(x = -90, y=-45))

#################################################

# status quo F
fsq <- mean(fbar(stk1)[,ac(dy:(dy-nsqy+1))])

#--------------------------------------------------------------------
# S/R
# use medians to avoid fitting to each iter
#--------------------------------------------------------------------

stk0 <- qapply(stk1, iterMedians)
gsr  <- as.FLSR(stk0, model = "bevholt")
gsr <- fmle(gsr)
plot(gsr)

#--------------------------------------------------------------------
# Set residuals for the projections period using residuals sd for
# rlnorm
#--------------------------------------------------------------------
res_gsr <- window(rec(stk1), end=fy)
res_gsr <- rlnorm(res_gsr, 0, sd(residuals(gsr)))
residuals(gsr) <- res_gsr
plot(residuals(gsr))

#--------------------------------------------------------------------
# reference points
#--------------------------------------------------------------------
brp_gsr <- brp(FLBRP(stk0, gsr))
refpts(brp_gsr)

#--------------------------------------------------------------------
# extend object for fwd, set up future assumptions - means of nsqy years
#--------------------------------------------------------------------
stk <- stf(stk1, fy-dy, nsqy, nsqy)
plot(stk)

#--------------------------------------------------------------------
# build OM object
#--------------------------------------------------------------------
# set projection method for OM
proj <- mseCtrl(method=fwd.om, args=list(maxF=3))
# build object
stk.om_altF <- FLom(stock=stk, sr=gsr, refpts=refpts(brp_gsr), projection=proj)

#====================================================================
# OM conditioning - Alternative sr model for projections
#====================================================================

#--------------------------------------------------------------------
# Assessment
#--------------------------------------------------------------------
brn <- 50 # If you dont use mcmc put burn equal zero to avoid mismatch dimension in the matrix later on
mcsave <- 100
mcmc <- mcsave*it
# mcmc setup object
scamcmc <- SCAMCMC(mcmc = mcmc, mcsave = mcsave, mcprobe = 0.3)

# submodels
qmod <- list(~s(age, k=3), ~s(age, k=3))
fmod <- ~te(age, year, k = c(3, 15)) + s(age, k = 5)
srmod <- ~geomean(CV=0.3)

# run
fit <- sca(aa.stk, idxs, fmodel=fmod, qmodel=qmod, srmodel=srmod, fit="MCMC", mcmc = scamcmc)
fit <- burnin(fit, brn)
stk <- aa.stk + fit
plot(stk)
wireframe(data ~ age + year, data = as.data.frame(harvest(stk)), drape = TRUE, screen = list(x = -90, y=-45))

# status quo F
fsq <- mean(fbar(stk)[,ac(dy:(dy-nsqy+1))])

#--------------------------------------------------------------------
# S/R
# use medians to avoid fitting to each iter
#--------------------------------------------------------------------

##### Alt setting ######################
# Try a different SR relationship (e.g. geomean, ricker)
stk0 <- qapply(stk, iterMedians)
gsr1  <- as.FLSR(stk0, model = "geomean")
gsr1 <- fmle(gsr1)
plot(gsr1)
#########################################

#--------------------------------------------------------------------
# Set residuals for the projections period using residuals sd for
# rlnorm
#--------------------------------------------------------------------
res_gsr1 <- window(rec(stk), end=fy)
res_gsr1 <- rlnorm(res_gsr1, 0, sd(residuals(gsr1)))
residuals(gsr1) <- res_gsr1
plot(residuals(gsr1))

#--------------------------------------------------------------------
# reference points
#--------------------------------------------------------------------
brp_gsr1 <- brp(FLBRP(stk0, gsr1))
refpts(brp_gsr1)

#--------------------------------------------------------------------
# extend object for fwd, set up future assumptions - means of nsqy years
#--------------------------------------------------------------------
stk <- stf(stk, fy-dy, nsqy, nsqy)
plot(stk)

#--------------------------------------------------------------------
# build OM object
#--------------------------------------------------------------------
# set projection method for OM
proj <- mseCtrl(method=fwd.om, args=list(maxF=3))
# build object
stk.om_geom <- FLom(stock=stk, sr=gsr1, refpts=refpts(brp_gsr1), projection=proj)

#====================================================================
# OM conditioning - fit SR to every iter
#====================================================================

#--------------------------------------------------------------------
# Assessment
#--------------------------------------------------------------------
brn <- 50 # If you dont use mcmc put burn equal zero to avoid mismatch dimension in the matrix later on
mcsave <- 100
mcmc <- mcsave*it
# mcmc setup object
scamcmc <- SCAMCMC(mcmc = mcmc, mcsave = mcsave, mcprobe = 0.3)

# submodels
qmod <- list(~s(age, k=3), ~s(age, k=3))
fmod <- ~te(age, year, k = c(3, 15)) + s(age, k = 5)
srmod <- ~geomean(CV=0.3)

# run
fit <- sca(aa.stk, idxs, fmodel=fmod, qmodel=qmod, srmodel=srmod, fit="MCMC", mcmc = scamcmc)
fit <- burnin(fit, brn)
stk <- aa.stk + fit
plot(stk)
wireframe(data ~ age + year, data = as.data.frame(harvest(stk)), drape = TRUE, screen = list(x = -90, y=-45))

# status quo F
fsq <- mean(fbar(stk)[,ac(dy:(dy-nsqy+1))])

#--------------------------------------------------------------------
# S/R
# use medians to avoid fitting to each iter
#--------------------------------------------------------------------

##### Alternative setting ###############
# Fit SR relationships to each iter rather than median
gsr2  <- as.FLSR(stk, model = "bevholt")
gsr2 <- fmle(gsr2)
plot(gsr2)
#########################################

#--------------------------------------------------------------------
# Set residuals for the projections period using residuals sd for
# rlnorm
#--------------------------------------------------------------------

res_gsr2 <- window(rec(stk), end=fy)
res_gsr2 <- rlnorm(res_gsr2, 0, sd(residuals(gsr2)))
residuals(gsr2) <- res_gsr2
plot(residuals(gsr2))

#--------------------------------------------------------------------
# reference points
#--------------------------------------------------------------------

brp_gsr2 <- brp(FLBRP(stk, gsr2))
refpts(brp_gsr2)
hist(refpts(brp_gsr2)[2,1], xlab="Fmsy estimate", main="")

#--------------------------------------------------------------------
# extend object for fwd, set up future assumptions - means of nsqy years
#--------------------------------------------------------------------
stk <- stf(stk, fy-dy, nsqy, nsqy)
plot(stk)

#--------------------------------------------------------------------
# build OM object
#--------------------------------------------------------------------
# set projection method for OM
proj <- mseCtrl(method=fwd.om, args=list(maxF=3))
# build object
stk.om_SRbyiter <- FLom(stock=stk, sr=gsr2, refpts=refpts(brp_gsr2), projection=proj)

#####################################################################

save(stk.om_base, file="om_base.RData")
save(stk.om_altF, file="om_altF.RData")
save(stk.om_geom, file="om_geom.RData")
save(stk.om_SRbyiter, file="om_SRbyiter.RData")



